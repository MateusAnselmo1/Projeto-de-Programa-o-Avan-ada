#ifndef CUTELLIPSOID_H
#define CUTELLIPSOID_H

#include "figurageometrica.h"
#include "sculptor.h"

// classe concreta a ser chamada
class CutEllipsoid : public FiguraGeometrica {

protected:
    int xcenter, ycenter, zcenter; // coordenadas do centro da elipsoide
    int rx, ry, rz;                // raios da elipsoide de acordo com cada direção

public:

    // construtor
    CutEllipsoid(int xcenter_ep, int ycenter_ep, int zcenter_ep,
                 int rx_ep, int ry_ep, int rz_ep);

    // destrutor
    ~CutEllipsoid();

    // método draw
    void draw(Sculptor &t);
};

#endif // CUTELLIPSOID_H
