#include "cutbox.h"

// construtor
CutBox::CutBox(int x0_bx, int x1_bx, int y0_bx, int y1_bx, int z0_bx, int z1_bx)
    : x0(x0_bx), x1(x1_bx), y0(y0_bx), y1(y1_bx), z0(z0_bx), z1(z1_bx) {

}

// destrutor
CutBox::~CutBox() {

}

// método draw
void CutBox::draw(Sculptor &t) {

    t.cutBox(x0, x1, y0, y1, z0, z1);// corta os voxels de acordo com as coordenadas, usando o parâmetro "t" no arquivo header
}
