#ifndef PUTBOX_H
#define PUTBOX_H

#include "FiguraGeometrica.h"
#include "sculptor.h"

// classe concreta a ser chamada
class PutBox : public FiguraGeometrica {

protected:
    int x0, x1, y0, y1, z0, z1; // limites iniciais e finais da box
    float r, g, b, a;           // cor e transparência da box

public:

    //construtor
    PutBox(int x0_bx, int x1_bx, int y0_bx, int y1_bx, int z0_bx, int z1_bx,
           float r_bx, float g_bx, float b_bx, float a_bx);

    //destrutor
    ~PutBox();

    //método draw
    void draw(Sculptor &t);
};

#endif // PUTBOX_H
