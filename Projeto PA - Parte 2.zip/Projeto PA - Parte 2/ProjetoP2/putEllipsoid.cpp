#include "putellipsoid.h"

// construtor
PutEllipsoid::PutEllipsoid(int xcenter_ep, int ycenter_ep, int zcenter_ep,
                           int rx_ep, int ry_ep, int rz_ep,
                           float r_ep, float g_ep, float b_ep, float a_ep)
    : xcenter(xcenter_ep), ycenter(ycenter_ep), zcenter(zcenter_ep),
    rx(rx_ep), ry(ry_ep), rz(rz_ep),
    r(r_ep), g(g_ep), b(b_ep), a(a_ep) {

}

// destrutor
PutEllipsoid::~PutEllipsoid() {

}

// método draw
void PutEllipsoid::draw(Sculptor &t) {

    t.setColor(r, g, b, a); // Define a cor e transparência da elipsoide, usando o parâmetro "t" no arquivo header

    t.putEllipsoid(xcenter, ycenter, zcenter, rx, ry, rz); // faz o elipsoide com base no centro e raios, usando o parâmetro "t" no arquivo header
}
