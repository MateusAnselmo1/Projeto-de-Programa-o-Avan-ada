#include "putvoxel.h"

// construtor
PutVoxel::PutVoxel(int x_vx, int y_vx, int z_vx, float r_vx, float g_vx, float b_vx, float a_vx)
    : x(x_vx), y(y_vx), z(z_vx), r(r_vx), g(g_vx), b(b_vx), a(a_vx) {

}

// destrutor
PutVoxel::~PutVoxel() {

}

// método draw
void PutVoxel::draw(Sculptor &t) {

    t.setColor(r, g, b, a);// define a cor de desenho no Sculptor, usando o parâmetro "t" no arquivo header

    t.putVoxel(x, y, z);// faz o voxel nas coordenadas especificadas, usando o parâmetro "t" no arquivo header
}
