#include "sculptor.h"
#include "figurageometrica.h"
#include "putvoxel.h"
#include "cutvoxel.h"
#include "putbox.h"
#include "cutbox.h"
#include "putsphere.h"
#include "cutsphere.h"
#include "putellipsoid.h"
#include "cutellipsoid.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

int main() {
    std::vector<FiguraGeometrica*> figuras;
    Sculptor *sculptor = nullptr;

    std::ifstream fileIn;
    std::string filename = "dim.txt";
    fileIn.open(filename);

    std::string line;
    while (std::getline(fileIn, line)) {
        if (line.empty()) {
            continue;
        }

        std::stringstream ss(line);
        std::string command;
        ss >> command;

        if (command == "dim") {
            int dimx, dimy, dimz;
            ss >> dimx >> dimy >> dimz;
            sculptor = new Sculptor(dimx, dimy, dimz);
            continue;
        }

        if (sculptor == nullptr) {
            std::cerr << "Erro: O comando 'dim' deve ser o primeiro no arquivo de script." << std::endl;
            return 1;
        }

        // Lógica para criar e armazenar as figuras
        if (command == "putvoxel") {
            int x, y, z; float r, g, b, a;
            ss >> x >> y >> z >> r >> g >> b >> a;
            figuras.push_back(new PutVoxel(x, y, z, r, g, b, a));
        } else if (command == "cutvoxel") {
            int x, y, z;
            ss >> x >> y >> z;
            figuras.push_back(new CutVoxel(x, y, z));
        } else if (command == "putbox") {
            int x0, x1, y0, y1, z0, z1; float r, g, b, a;
            ss >> x0 >> x1 >> y0 >> y1 >> z0 >> z1 >> r >> g >> b >> a;
            figuras.push_back(new PutBox(x0, x1, y0, y1, z0, z1, r, g, b, a));
        } else if (command == "cutbox") {
            int x0, x1, y0, y1, z0, z1;
            ss >> x0 >> x1 >> y0 >> y1 >> z0 >> z1;
            figuras.push_back(new CutBox(x0, x1, y0, y1, z0, z1));
        } else if (command == "putsphere") {
            int x, y, z, radius; float r, g, b, a;
            ss >> x >> y >> z >> radius >> r >> g >> b >> a;
            figuras.push_back(new PutSphere(x, y, z, radius, r, g, b, a));
        } else if (command == "cutsphere") {
            int x, y, z, radius;
            ss >> x >> y >> z >> radius;
            figuras.push_back(new CutSphere(x, y, z, radius));
        } else if (command == "putellipsoid") {
            int x, y, z, rx, ry, rz; float r, g, b, a;
            ss >> x >> y >> z >> rx >> ry >> rz >> r >> g >> b >> a;
            figuras.push_back(new PutEllipsoid(x, y, z, rx, ry, rz, r, g, b, a));
        } else if (command == "cutellipsoid") {
            int x, y, z, rx, ry, rz;
            ss >> x >> y >> z >> rx >> ry >> rz;
            figuras.push_back(new CutEllipsoid(x, y, z, rx, ry, rz));
        }
    }
    fileIn.close();

    if (sculptor == nullptr) {
        std::cerr << "Erro: O arquivo de script nao contem o comando 'dim' ou esta vazio." << std::endl;
        return 1;
    }

    // Loop para desenhar as figuras armazenadas na lista
    for (const auto& fig : figuras) {
        fig->draw(*sculptor);
    }

    // Chama a função para escrever o arquivo de saída
    sculptor->writeOFF("desenho_final.off");

    // Limpa a memória alocada
    for (auto fig : figuras) {
        delete fig;
    }
    delete sculptor;

    return 0; // Termina com sucesso
}
