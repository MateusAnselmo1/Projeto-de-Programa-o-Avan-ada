#ifndef PUTELLIPSOID_H
#define PUTELLIPSOID_H

#include "figurageometrica.h"
#include "sculptor.h"

// classe concreta a ser chamada

class PutEllipsoid : public FiguraGeometrica {

protected:
    int xcenter, ycenter, zcenter; // coordenadas do centro da elipsoide
    int rx, ry, rz;                // raio da elipsoide nas diferentes direções
    float r, g, b, a;              // cor e transparência da elipsoide

public:

    // construtor
    PutEllipsoid(int xcenter_ep, int ycenter_ep, int zcenter_ep,
                 int rx_ep, int ry_ep, int rz_ep,
                 float r_ep, float g_ep, float b_ep, float a_ep);

    // destrutor
    ~PutEllipsoid();

    // método draw
    void draw(Sculptor &t);
};

#endif // PUTELLIPSOID_H
