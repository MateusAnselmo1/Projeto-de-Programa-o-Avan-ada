#include "putsphere.h"

// construtor
PutSphere::PutSphere(int xcenter_sp, int ycenter_sp, int zcenter_sp, int radius_sp,
                     float r_sp, float g_sp, float b_sp, float a_sp)
    : xcenter(xcenter_sp), ycenter(ycenter_sp), zcenter(zcenter_sp), radius(radius_sp),
    r(r_sp), g(g_sp), b(b_sp), a(a_sp) {

}

// destrutor
PutSphere::~PutSphere() {

}

// método draw
void PutSphere::draw(Sculptor &t) {

    t.setColor(r, g, b, a); // define a cor e transparência da esfera, usando o parâmetro "t" no arquivo header

    t.putSphere(xcenter, ycenter, zcenter, radius); // faz a esfera de acordo com as coordenadas, usando o parâmetro "t" no arquivo header
}
