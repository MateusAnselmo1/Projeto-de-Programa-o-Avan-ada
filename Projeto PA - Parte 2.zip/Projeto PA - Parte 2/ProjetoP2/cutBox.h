#ifndef CUTBOX_H
#define CUTBOX_H

#include "FiguraGeometrica.h"
#include "sculptor.h"

// classe concreta a ser chamada

class CutBox : public FiguraGeometrica {

protected:
    int x0, x1, y0, y1, z0, z1; // coordenadas a serem cortadas na box

public:

    // construtor
    CutBox(int x0_in, int x1_in, int y0_in, int y1_in, int z0_in, int z1_in);

    // destrutor
    ~CutBox();

    // método draw
    void draw(Sculptor &t);
};

#endif // CUTBOX_H
