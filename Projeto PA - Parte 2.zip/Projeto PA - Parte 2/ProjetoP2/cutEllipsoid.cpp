#include "cutellipsoid.h"

// construtor
CutEllipsoid::CutEllipsoid(int xcenter_ep, int ycenter_ep, int zcenter_ep,
                           int rx_ep, int ry_ep, int rz_ep)
    : xcenter(xcenter_ep), ycenter(ycenter_ep), zcenter(zcenter_ep),
    rx(rx_ep), ry(ry_ep), rz(rz_ep) {

}

// destrutor
CutEllipsoid::~CutEllipsoid() {

}

// método draw
void CutEllipsoid::draw(Sculptor &t) {

    t.cutEllipsoid(xcenter, ycenter, zcenter, rx, ry, rz); // corta o elipsoide com base no centro e raios, usando o parâmetro "t" no arquivo header
}
