#include "cutsphere.h"

// construtor
CutSphere::CutSphere(int xcenter_sp, int ycenter_sp, int zcenter_sp, int radius_sp)
    : xcenter(xcenter_sp), ycenter(ycenter_sp), zcenter(zcenter_sp), radius(radius_sp) {

}

// destrutor
CutSphere::~CutSphere() {

}

// método draw
void CutSphere::draw(Sculptor &t) {

    t.cutSphere(xcenter, ycenter, zcenter, radius); // corta a esfera com base nas coordenadas, usando o parâmetro "t" no arquivo header
}
