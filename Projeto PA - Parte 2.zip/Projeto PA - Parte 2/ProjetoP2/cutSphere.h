#ifndef CUTSPHERE_H
#define CUTSPHERE_H

#include "FiguraGeometrica.h"
#include "sculptor.h"

// classe concreta a ser chamada

class CutSphere : public FiguraGeometrica {

protected:
    int xcenter, ycenter, zcenter; // coordenadas do centro da esfera
    int radius;                    // raio da esfera

public:

    // construtor
    CutSphere(int xcenter_sp, int ycenter_sp, int zcenter_sp, int radius_sp);

    // destrutor
    ~CutSphere();

    // método draw
    void draw(Sculptor &t);
};

#endif // CUTSPHERE_H
