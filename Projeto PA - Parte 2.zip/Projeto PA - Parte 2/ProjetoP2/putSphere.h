#ifndef PUTSPHERE_H
#define PUTSPHERE_H

#include "FiguraGeometrica.h"
#include "sculptor.h"

// classe concreta a ser chamada
class PutSphere : public FiguraGeometrica {

protected:
    int xcenter, ycenter, zcenter; // coordenadas do centro da esfera
    int radius;                    // raio da esfera
    float r, g, b, a;              // cor e transparência da esfera

public:

    // construtor
    PutSphere(int xcenter_sp, int ycenter_sp, int zcenter_sp, int radius_sp,
              float r_sp, float g_sp, float b_sp, float a_sp);

    // destrutor
    ~PutSphere();

    // método draw
    void draw(Sculptor &t);
};

#endif // PUTSPHERE_H
