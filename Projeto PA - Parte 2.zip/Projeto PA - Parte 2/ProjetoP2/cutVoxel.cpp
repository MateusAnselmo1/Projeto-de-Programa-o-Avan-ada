#include "cutVoxel.h"

//construtor
CutVoxel::CutVoxel(int x_vx, int y_vx, int z_vx)
    : x(x_vx), y(y_vx), z(z_vx) {

}

//destrutor
CutVoxel::~CutVoxel() {

}

// método draw
void CutVoxel::draw(Sculptor &t) {

    t.cutVoxel(x, y, z); // corta os voxel's na coordenada específicada, usando o parâmetro "t" no arquivo header
}
