#include "figurageometrica.h"

// construtor
FiguraGeometrica::FiguraGeometrica() {

}

// destrutor
FiguraGeometrica::~FiguraGeometrica() {

}

// usado apenas para a cadeia de construção e destruição de objetos
