#ifndef PUTVOXEL_H
#define PUTVOXEL_H

#include "FiguraGeometrica.h"
#include "sculptor.h"

//Classe concreta a ser chamada

class PutVoxel : public FiguraGeometrica {
protected:
    int x, y, z;      // coordenadas x,y,z do voxel
    float r, g, b, a; // cor e transparência
public:

    PutVoxel(int x_vx, int y_vx, int z_vx, float r_vx, float g_vx, float b_vx, float a_vx); // construtor do putVoxel

    ~PutVoxel(); // Destrutor do putVoxel

    // método do draw
    void draw(Sculptor &t);
};

#endif // PUTVOXEL_H
