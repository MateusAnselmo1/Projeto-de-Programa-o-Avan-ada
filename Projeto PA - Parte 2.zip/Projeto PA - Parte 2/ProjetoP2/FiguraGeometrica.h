#ifndef FIGURAGEOMETRICA_H
#define FIGURAGEOMETRICA_H

#include "sculptor.h" // Inclui a classe Sculptor para que draw possa usá-la

//classe abstrata

class FiguraGeometrica {
public:
    // construtor da classe
    FiguraGeometrica();

    // destrutor da classe
    virtual ~FiguraGeometrica();

    // método draw
    virtual void draw(Sculptor &t) = 0;
};

#endif // FIGURAGEOMETRICA_H
