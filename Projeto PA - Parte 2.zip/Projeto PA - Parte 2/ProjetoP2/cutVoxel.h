#ifndef CUTVOXEL_H
#define CUTVOXEL_H

#include "FiguraGeometrica.h" // Inclui a classe base abstrata
#include "sculptor.h"         // Inclui Sculptor, já que CutVoxel usará seus métodos

//Classe concreta a ser chamada

class CutVoxel : public FiguraGeometrica {
protected:
    int x, y, z;
public:

    CutVoxel(int x_in, int y_in, int z_in); //construtor

    ~CutVoxel(); //destrutor

    // método draw
    void draw(Sculptor &t);
};

#endif // CUTVOXEL_H
