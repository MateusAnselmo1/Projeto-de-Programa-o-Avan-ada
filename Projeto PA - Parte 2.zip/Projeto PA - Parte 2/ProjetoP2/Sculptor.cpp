#include "sculptor.h"
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>

// Construtor: Aloca a matriz 3D e inicializa todos os voxels.
Sculptor::Sculptor(int _nx, int _ny, int _nz) {
    nx = _nx;
    ny = _ny;
    nz = _nz;

    // Aloca a matriz 3D
    v = new Voxel **[nx];
    for (int i = 0; i < nx; i++) {
        v[i] = new Voxel *[ny];
        for (int j = 0; j < ny; j++) {
            v[i][j] = new Voxel[nz];
            // Inicializa cada voxel
            for (int k = 0; k < nz; k++) {
                v[i][j][k].show = false;
                v[i][j][k].r = 0.0f; // Usar 0.0f para floats
                v[i][j][k].g = 0.0f;
                v[i][j][k].b = 0.0f;
                v[i][j][k].a = 0.0f;
            }
        }
    }
}

// Destrutor: Libera a memória alocada dinamicamente.
Sculptor::~Sculptor() {
    for (int i = 0; i < nx; i++) {
        for (int j = 0; j < ny; j++) {
            delete[] v[i][j];
        }
        delete[] v[i];
    }
    delete[] v;
}

// Define a cor.
void Sculptor::setColor(float r, float g, float b, float a) {
    this->r = r;
    this->g = g;
    this->b = b;
    this->a = a;
}

// Ativa um voxel específico.
void Sculptor::putVoxel(int x, int y, int z) {
    // Verificação de limites para evitar erros de acesso à memória
    if (x >= 0 && x < nx && y >= 0 && y < ny && z >= 0 && z < nz) {
        v[x][y][z].show = true;
        v[x][y][z].r = this->r;
        v[x][y][z].g = this->g;
        v[x][y][z].b = this->b;
        v[x][y][z].a = this->a;
    }
}

// Apaga um voxel específico.
void Sculptor::cutVoxel(int x, int y, int z) {
    if (x >= 0 && x < nx && y >= 0 && y < ny && z >= 0 && z < nz) {
        v[x][y][z].show = false;
    }
}

// Cria uma caixa de voxels.
void Sculptor::putBox(int x0, int x1, int y0, int y1, int z0, int z1) {
    for (int i = x0; i <= x1; i++) {
        for (int j = y0; j <= y1; j++) {
            for (int k = z0; k <= z1; k++) {
                putVoxel(i, j, k);
            }
        }
    }
}

// Apaga uma caixa de voxels.
void Sculptor::cutBox(int x0, int x1, int y0, int y1, int z0, int z1) {
    for (int i = x0; i <= x1; i++) {
        for (int j = y0; j <= y1; j++) {
            for (int k = z0; k <= z1; k++) {
                cutVoxel(i, j, k);
            }
        }
    }
}

// Cria uma esfera.
void Sculptor::putSphere(int xcenter, int ycenter, int zcenter, int radius) {
    for (int i = xcenter - radius; i <= xcenter + radius; i++) {
        for (int j = ycenter - radius; j <= ycenter + radius; j++) {
            for (int k = zcenter - radius; k <= zcenter + radius; k++) {
                // A equação da esfera: (x-xc)² + (y-yc)² + (z-zc)² <= r²
                if ((float)(i - xcenter) * (i - xcenter) +
                        (float)(j - ycenter) * (j - ycenter) +
                        (float)(k - zcenter) * (k - zcenter) <= (float)radius * radius) {
                    putVoxel(i, j, k);
                }
            }
        }
    }
}

// Apaga uma esfera.
void Sculptor::cutSphere(int xcenter, int ycenter, int zcenter, int radius) {
    for (int i = xcenter - radius; i <= xcenter + radius; i++) {
        for (int j = ycenter - radius; j <= ycenter + radius; j++) {
            for (int k = zcenter - radius; k <= zcenter + radius; k++) {
                if ((float)(i - xcenter) * (i - xcenter) +
                        (float)(j - ycenter) * (j - ycenter) +
                        (float)(k - zcenter) * (k - zcenter) <= (float)radius * radius) {
                    cutVoxel(i, j, k);
                }
            }
        }
    }
}

// Cria uma elipsoide.
void Sculptor::putEllipsoid(int xcenter, int ycenter, int zcenter, int rx, int ry, int rz) {
    for (int i = xcenter - rx; i <= xcenter + rx; i++) {
        for (int j = ycenter - ry; j <= ycenter + ry; j++) {
            for (int k = zcenter - rz; k <= zcenter + rz; k++) {
                // A equação da elipsoide.
                if (((float)(i - xcenter) * (i - xcenter) / (rx * rx)) +
                        ((float)(j - ycenter) * (j - ycenter) / (ry * ry)) +
                        ((float)(k - zcenter) * (k - zcenter) / (rz * rz)) <= 1.0) {
                    putVoxel(i, j, k);
                }
            }
        }
    }
}

// Apaga uma elipsoide.
void Sculptor::cutEllipsoid(int xcenter, int ycenter, int zcenter, int rx, int ry, int rz) {
    for (int i = xcenter - rx; i <= xcenter + rx; i++) {
        for (int j = ycenter - ry; j <= ycenter + ry; j++) {
            for (int k = zcenter - rz; k <= zcenter + rz; k++) {
                if (((float)(i - xcenter) * (i - xcenter) / (rx * rx)) +
                        ((float)(j - ycenter) * (j - ycenter) / (ry * ry)) +
                        ((float)(k - zcenter) * (k - zcenter) / (rz * rz)) <= 1.0) {
                    cutVoxel(i, j, k);
                }
            }
        }
    }
}

// Escreve a escultura em um arquivo no formato OFF.
void Sculptor::writeOFF(const char *filename) {
    std::ofstream fout;
    int vOn = 0;
    int current_voxel = 0;

    fout.open(filename);

    // Se o arquivo não puder ser aberto, avisa e encerra a função.
    if (!fout.is_open()) {
        std::cerr << "Erro: Falha ao criar o arquivo de saida '" << filename << "'" << std::endl;
        return;
    }

    // Conta quantos voxels estão ativos para escrever o cabeçalho do arquivo.
    for (int i = 0; i < nx; i++) {
        for (int j = 0; j < ny; j++) {
            for (int k = 0; k < nz; k++) {
                if (v[i][j][k].show) {
                    vOn++;
                }
            }
        }
    }

    fout << "OFF" << std::endl;
    fout << vOn * 8 << " " << vOn * 6 << " 0" << std::endl;

    // Escreve os 8 vértices de cada voxel ativo.
    for (int i = 0; i < nx; i++) {
        for (int j = 0; j < ny; j++) {
            for (int k = 0; k < nz; k++) {
                if (v[i][j][k].show) {
                    // CORREÇÃO: Vértices agora em ordem padrão
                    fout << i - 0.5 << " " << j - 0.5 << " " << k - 0.5 << std::endl; // Vértice 0
                    fout << i + 0.5 << " " << j - 0.5 << " " << k - 0.5 << std::endl; // Vértice 1
                    fout << i + 0.5 << " " << j + 0.5 << " " << k - 0.5 << std::endl; // Vértice 2
                    fout << i - 0.5 << " " << j + 0.5 << " " << k - 0.5 << std::endl; // Vértice 3
                    fout << i - 0.5 << " " << j - 0.5 << " " << k + 0.5 << std::endl; // Vértice 4
                    fout << i + 0.5 << " " << j - 0.5 << " " << k + 0.5 << std::endl; // Vértice 5
                    fout << i + 0.5 << " " << j + 0.5 << " " << k + 0.5 << std::endl; // Vértice 6
                    fout << i - 0.5 << " " << j + 0.5 << " " << k + 0.5 << std::endl; // Vértice 7
                }
            }
        }
    }

    // Escreve as 6 faces de cada voxel ativo.
    for (int i = 0; i < nx; i++) {
        for (int j = 0; j < ny; j++) {
            for (int k = 0; k < nz; k++) {
                if (v[i][j][k].show) {
                    int base = current_voxel * 8;
                    fout << std::fixed;
                    fout << "4 " << base + 0 << " " << base + 3 << " " << base + 2 << " " << base + 1 << " "
                         << std::setprecision(3) << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << std::endl;
                    fout << "4 " << base + 4 << " " << base + 5 << " " << base + 6 << " " << base + 7 << " "
                         << std::setprecision(3) << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << std::endl;
                    fout << "4 " << base + 0 << " " << base + 4 << " " << base + 7 << " " << base + 3 << " "
                         << std::setprecision(3) << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << std::endl;
                    fout << "4 " << base + 1 << " " << base + 2 << " " << base + 6 << " " << base + 5 << " "
                         << std::setprecision(3) << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << std::endl;
                    fout << "4 " << base + 0 << " " << base + 1 << " " << base + 5 << " " << base + 4 << " "
                         << std::setprecision(3) << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << std::endl;
                    fout << "4 " << base + 3 << " " << base + 7 << " " << base + 6 << " " << base + 2 << " "
                         << std::setprecision(3) << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << std::endl;

                    current_voxel++;
                }
            }
        }
    }
    fout.close();
    std::cout << "Arquivo '" << filename << "' gerado com sucesso." << std::endl;
}
