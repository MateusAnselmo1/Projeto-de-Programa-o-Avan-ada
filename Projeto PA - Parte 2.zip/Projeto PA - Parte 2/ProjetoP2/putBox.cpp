#include "putbox.h"

// construtor
PutBox::PutBox(int x0_bx, int x1_bx, int y0_bx, int y1_bx, int z0_bx, int z1_bx,
               float r_bx, float g_bx, float b_bx, float a_bx)
    : x0(x0_bx), x1(x1_bx), y0(y0_bx), y1(y1_bx), z0(z0_bx), z1(z1_bx),
    r(r_bx), g(g_bx), b(b_bx), a(a_bx) {

}

//destrutor
PutBox::~PutBox() {

}

// método draw
void PutBox::draw(Sculptor &t) {

    t.setColor(r, g, b, a); // define a cor e a transparência da box, usando o parâmetro "t" no arquivo header

    t.putBox(x0, x1, y0, y1, z0, z1); // faz a box de acordo com as dimensões, usando o parâmetro "t" no arquivo header
}
